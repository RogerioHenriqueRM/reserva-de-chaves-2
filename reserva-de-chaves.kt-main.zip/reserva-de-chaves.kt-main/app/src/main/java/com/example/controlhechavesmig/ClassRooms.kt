package com.example.controlhechavesmig
// sala de aula
data class Sala(
    val numero: String,
    val id: String

) {}

